package model;

public enum ShoppingCartStatus {

    OPEN, CANCELLED, COMPLETED
}
